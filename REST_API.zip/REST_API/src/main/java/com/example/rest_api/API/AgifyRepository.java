package com.example.rest_api.API;

import org.springframework.boot.autoconfigure.data.jpa.JpaRepositoriesAutoConfiguration;
import org.springframework.stereotype.Repository;

public interface AgifyRepository extends Repository {
// nestihl jsem
}
