package com.example.rest_api.API;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AhojController {
    @GetMapping("/ahoj") // První kroky pouze zda funguje java + verze .jdks neslo mi to chvilku srovnat.
    public String greetMessage(){
        return "Ahoj Svete";
    }
}
